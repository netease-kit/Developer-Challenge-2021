package com.ml.doctor.bean;

/**
 * Created by gzq on 2017/11/21.
 * 登陆成功返回的字段
 */

public class LoginBean {
    public String docterid;
    public String doctername;
    public String tel;
    public String adds;
    public String duty;
    public String department;
    public String state;
    public String priority;
    public String documents;
    public String card;
    public String amount;
    public String gat;
    public String pro;
    public String tj;
    public String pend;
    public String number;
    public String evaluation;
    public String apply_amount;
    public String service_amount;
    public String docter_photo;
    public String hosname;
    public String online_status;
    public R r;
    public static class R{
        public String rankid;
        public String rankname;
    }

}
