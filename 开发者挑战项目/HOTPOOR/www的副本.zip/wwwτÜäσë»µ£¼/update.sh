coffee -c -o static/js static/coffee
rsync -avz . ubuntu@122.51.169.191:~/xialiwei/findmaster_www/