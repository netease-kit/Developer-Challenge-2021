#!/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
import os.path

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/vendor/')

import re
import uuid
import time
import random
import string
import hashlib
import urllib
import copy
from functools import partial
import logging
import datetime

import markdown
import tornado
import tornado.web
import tornado.escape
import tornado.websocket
import tornado.httpclient
import tornado.gen
from tornado.escape import json_encode, json_decode

import nomagic
import nomagic.auth
import nomagic.block
from nomagic.cache import get_user, get_users, update_user, get_doc, get_docs, update_doc, get_aim, get_aims, update_aim, get_entity, get_entities, update_entity
from nomagic.cache import BIG_CACHE
from setting import settings
from setting import conn

# from user_agents import parse as uaparse #早年KJ用来判断设备使用

from .base import WebRequest
from .base import WebSocket
import pymail

from .data import DataWebSocket


class MainHandler(WebRequest):
    @tornado.gen.coroutine
    def get(self, app):
        # self.time_now = int(time.time())
        # self._ = self.locale.translate
        # self.render("../template/index.html")
        if not self.current_user:
            self.redirect("/login")
        else:
            self.redirect("/home/pages")
class LoginHandler(WebRequest):
    @tornado.gen.coroutine
    def get(self):
        self.time_now = int(time.time())
        self._ = self.locale.translate
        self.render("../template/login.html")
class MainHomeHandler(WebRequest):
    def get(self):
        self.timer = int(time.time())
        self.render("../template/main.html")
class WelcomeHomeHandler(WebRequest):
    def get(self):
        self.timer = int(time.time())
        self.render("../template/welcome.html")
class PagesHomeHandler(WebRequest):
    def get(self):
        self.time_now = int(time.time())
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        user = get_aim(user_id)
        self.pages = user.get("pages",[])
        self.render("../template/pages.html")
class PagesListAPIHandler(WebRequest):
    def get(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        user = get_aim(user_id)
        pages_ids = user.get("pages",[])
        pages = get_aims(pages_ids)
        result = []
        for page in pages:
            result_item = [page[0],page[1].get("title","new page"),page[1].get("desc","this is a new page")]
            result.append(result_item)
        self.finish({"info":"ok","result":result})

class PageAddAPIHandler(WebRequest):
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        title = self.get_argument("title","new page")
        desc = self.get_argument("desc","this is a new page")
        user = get_aim(user_id)
        pages = user.get("pages",[])
        block = {
            "owner":user_id,
            "subtype":"page",
            "title":title,
            "desc":desc,
            "doms":[],
            "history":[],
            "updatetime":int(time.time())
        }
        [block_id,block]=nomagic.block.create_block(block)
        pages.insert(0,block_id)
        user["pages"]=pages
        update_aim(user_id,user)
        self.finish({"info":"ok","about":"create new page success","block_id":block_id})
class PageHomeHandler(WebRequest):
    def get(self,block_id):
        # self.set_header("Access-Control-Allow-Origin", self.request.headers.get("Origin","*"))
        # self.set_header("Access-Control-Allow-Credentials", "true")
        if not self.current_user:
            self.user_id = "no_login:%s"%str(time.time())
        else:
            self.user_id = self.current_user["id"]
        self.time_now = int(time.time())
        self.block_id = block_id
        block = get_aim(block_id)
        if not block:
            self.render("../template/404.html")
            return

        self.permission = block.get("permission","private")
        self.editors = block.get("editors",[block.get("owner",None)])
        self.readers = block.get("readers",[])
        self.blackers = block.get("blackers",[])
        if self.user_id in self.blackers:
            self.render("../template/404.html")
            return
        if self.permission in ["private"]:
            if self.user_id not in self.editors and self.user_id not in self.readers:
                self.render("../template/404.html")
                return

        self.doms = block.get("doms",[])
        websocket_protocol = "ws" if self.request.protocol == "http" else "wss"
        aim_host = self.request.host
        self.websocket_url = "%s://%s/api/data/ws?aim_id=%s" % (websocket_protocol, aim_host, block_id)
        
        self.render("../template/page.html")
class PageEditHomeHandler(WebRequest):
    def get(self,block_id):
        # self.set_header("Access-Control-Allow-Origin", self.request.headers.get("Origin","*"))
        # self.set_header("Access-Control-Allow-Credentials", "true")
        if not self.current_user:
            self.user_id = "no_login:%s"%str(time.time())
        else:
            self.user_id = self.current_user["id"]
        self.time_now = int(time.time())
        self.block_id = block_id
        block = get_aim(block_id)
        if not block:
            self.render("../template/404.html")
            return
        self.doms = block.get("doms",[])
        websocket_protocol = "ws" if self.request.protocol == "http" else "wss"
        aim_host = self.request.host
        self.websocket_url = "%s://%s/api/data/ws?aim_id=%s" % (websocket_protocol, aim_host, block_id)

        self.permission = block.get("permission","private")
        self.editors = block.get("editors",[block.get("owner",None)])
        self.readers = block.get("readers",[])
        self.blackers = block.get("blackers",[])
        self.members = block.get("members",[])

        if self.user_id in self.blackers:
            self.render("../template/404.html")
            return

        if self.permission not in ["public"]:
            if self.user_id not in self.editors:
                self.redirect("/home/page/%s"%block_id)
                return
        self.render("../template/page_edit.html")
class PageFixHomeHandler(WebRequest):
    def get(self,block_id):
        # self.set_header("Access-Control-Allow-Origin", self.request.headers.get("Origin","*"))
        # self.set_header("Access-Control-Allow-Credentials", "true")
        if not self.current_user:
            self.user_id = "no_login:%s"%str(time.time())
        else:
            self.user_id = self.current_user["id"]
        self.time_now = int(time.time())
        self.block_id = block_id
        block = get_aim(block_id)
        if not block:
            self.render("../template/404.html")
            return
        self.doms = block.get("doms",[])
        websocket_protocol = "ws" if self.request.protocol == "http" else "wss"
        aim_host = self.request.host
        self.websocket_url = "%s://%s/api/data/ws?aim_id=%s" % (websocket_protocol, aim_host, block_id)

        self.permission = block.get("permission","private")
        self.editors = block.get("editors",[block.get("owner",None)])
        self.readers = block.get("readers",[])
        self.blackers = block.get("blackers",[])
        self.members = block.get("members",[])

        if self.user_id in self.blackers:
            self.render("../template/404.html")
            return

        if self.permission not in ["public"]:
            if self.user_id not in self.editors:
                self.redirect("/home/page/%s"%block_id)
                return
        self.render("../template/page_fix.html")
class PageAddDomAPIHandler(WebRequest):
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        block_id = self.get_argument("block_id",None)
        dom_owner = self.get_argument("dom_owner",None)
        dom_type = self.get_argument("dom_type","text")
        dom_position_x = int(float(self.get_argument("dom_position_x","0")))
        dom_position_y = int(float(self.get_argument("dom_position_y","0")))
        # if dom_type not in ["text","img","video","canvas","input","button","textarea"]:
        if dom_type not in ["text","img","video","iframe"]:
            self.finish({"info":"error","about":"not allow dom type"})
            return
        block = get_aim(block_id)
        #判断是否为编辑者
        if user_id not in block.get("editors",[block.get("owner",None)]):
        # if block.get("owner",None) != user_id:
            self.finish({"info":"error","about":"no in editors"})
            return
        doms = block.get("doms",[])
        dom_sequence = "".join(random.choice(string.ascii_lowercase+string.digits) for _ in range(6))
        dom_position = {
            "x":dom_position_x,
            "y":dom_position_y,
            "w":100,
            "h":40,
            "z":0,
        }
        dom_css = ""
        dom_content = ""
        dom_children = []
        updatetime = int(time.time())
        dom = [dom_sequence,dom_type,dom_position,dom_content,dom_css,dom_children,updatetime]
        doms.append(dom)
        block["doms"] = doms
        block["updatetime"] = updatetime
        update_aim(block_id,block)
        self.finish({"info":"ok",})

        if dom_type in ["text"]:
            dom_content = """
            <div class="section">text</div>
            """
        elif dom_type in ["img"]:
            dom_content = """
            <div class="section"><img src="/static/img/oflogo.png"></div>
            """
        elif dom_type in ["video"]:
            dom_content = """
            <div class="section" contenteditable="false">视频暂未设置</div>
            """
        elif dom_type in ["iframe"]:
            dom_content = """
            <div class="section" contenteditable="false">iframe暂未设置</div>
            """
        content_data = {
            "dom_current":dom_sequence,
            "dom_content":dom_content,
            "dom_position_x":dom_position["x"],
            "dom_position_y":dom_position["y"],
            "dom_position_w":dom_position["w"],
            "dom_position_h":dom_position["h"],
            "dom_position_z":dom_position["z"],
            "dom_type":dom_type
        }
        msgtype = "COMMENTPAGEADDDOM"
        msg = [msgtype, {
            "content": content_data,
            "nickname": "",
            "headimgurl": "/static/img/oflogo.png",
            "tel": "",
            "time": updatetime,
            "user_id": user_id,
            "sequence": "",
            "comment_id": ""
        }, block_id]
        DataWebSocket.send_to_all(json_encode(msg))
class PageDelDomAPIHandler(WebRequest):
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        block_id = self.get_argument("block_id",None)
        dom_owner = self.get_argument("dom_owner",None)
        dom_current = self.get_argument("dom_current",None)

        block = get_aim(block_id)
        #判断是否为编辑者
        if user_id not in block.get("editors",[block.get("owner",None)]):
        # if block.get("owner",None) != user_id:
            self.finish({"info":"error","about":"no in editors"})
            return
        doms = block.get("doms",[])
        dom_tree = dom_current.split("_")
        dom_aim = None
        doms = block.get("doms",[])

        _doms = doms
        for dom in dom_tree:
            _doms = _doms
            for _dom in _doms:
                if dom == _dom[0]:
                    if dom_owner == _dom[0]:
                        dom_aim = _dom
                        _doms.remove(_dom)
                        break
                    _doms = _dom[5]
                    break
        if not dom_aim:
            self.finish({"info":"error","about":"no dom"})
            return
        dom_content = ""
        updatetime = int(time.time())
        block["doms"] = doms
        block["updatetime"] = updatetime
        update_aim(block_id,block)
        self.finish({"info":"ok",})
        content_data = {
            "dom_current":dom_current,
            "dom_content":dom_content,
        }
        msgtype = "COMMENTPAGEDELDOM"
        msg = [msgtype, {
            "content": content_data,
            "nickname": "",
            "headimgurl": "/static/img/oflogo.png",
            "tel": "",
            "time": updatetime,
            "user_id": user_id,
            "sequence": "",
            "comment_id": ""
        }, block_id]
        DataWebSocket.send_to_all(json_encode(msg))

class PageUpdateDomAPIHandler(WebRequest):
    # @tornado.gen.coroutine
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        block_id = self.get_argument("block_id",None)
        dom_owner = self.get_argument("dom_owner",None)
        dom_current = self.get_argument("dom_current",None)
        dom_position_x = int(float(self.get_argument("dom_position_x","0")))
        dom_position_y = int(float(self.get_argument("dom_position_y","0")))
        dom_position_w = int(float(self.get_argument("dom_position_w","0")))
        dom_position_h = int(float(self.get_argument("dom_position_h","0")))
        dom_position_z = int(float(self.get_argument("dom_position_z","0")))
        
        updatetime = int(time.time())
        
        block = get_aim(block_id)
        
        #判断是否为编辑者
        if user_id not in block.get("editors",[block.get("owner",None)]):
        # if block.get("owner",None) != user_id:
            self.finish({"info":"error","about":"no in editors"})
            return
        dom_tree = dom_current.split("_")
        dom_aim = None
        doms = block.get("doms",[])

        _doms = doms
        for dom in dom_tree:
            _doms = _doms
            for _dom in _doms:
                if dom == _dom[0]:
                    if dom_owner == _dom[0]:
                        dom_aim = _dom
                        dom_aim[2]={
                            "x":dom_position_x,
                            "y":dom_position_y,
                            "w":dom_position_w,
                            "h":dom_position_h,
                            "z":dom_position_z,
                        }
                        dom_aim[6]=updatetime
                        break
                    _doms = _dom[5]
                    break
        block["doms"]=doms
        block["updatetime"]=updatetime
        update_aim(block_id,block)
        self.finish({"info":"ok"})
        content_data = {
            "dom_current":dom_current,
            "dom_position_x":dom_position_x,
            "dom_position_y":dom_position_y,
            "dom_position_w":dom_position_w,
            "dom_position_h":dom_position_h,
            "dom_position_z":dom_position_z,
        }

        msgtype = "COMMENTPAGEUPDATEDOM"
        msg = [msgtype, {
            "content": content_data,
            "nickname": "",
            "headimgurl": "/static/img/oflogo.png",
            "tel": "",
            "time": updatetime,
            "user_id": user_id,
            "sequence": "",
            "comment_id": ""
        }, block_id]
        DataWebSocket.send_to_all(json_encode(msg))
class PageUpdateDomVideoAPIHandler(WebRequest):
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        block_id = self.get_argument("block_id",None)
        dom_owner = self.get_argument("dom_owner",None)
        dom_current = self.get_argument("dom_current",None)
        dom_content = self.get_argument("dom_content",None)
        
        updatetime = int(time.time())
        
        block = get_aim(block_id)
        #判断是否为编辑者
        if user_id not in block.get("editors",[block.get("owner",None)]):
            self.finish({"info":"error","about":"no in editors"})
            return
        dom_tree = dom_current.split("_")
        dom_aim = None
        doms = block.get("doms",[])

        _doms = doms
        for dom in dom_tree:
            _doms = _doms
            for _dom in _doms:
                if dom == _dom[0]:
                    if dom_owner == _dom[0]:
                        dom_aim = _dom
                        dom_aim[3] = json_decode(dom_content).get("text",{})
                        dom_aim[6] =updatetime
                        break
                    _doms = _dom[5]
                    break
        block["doms"]=doms
        block["updatetime"]=updatetime

        update_aim(block_id,block)
        self.finish({"info":"ok"})
        content_data = {
            "dom_current":dom_current,
            "dom_content":dom_content,
        }
        msgtype = "COMMENTPAGEUPDATEDOMVIDEO"
        msg = [msgtype, {
            "content": content_data,
            "nickname": "",
            "headimgurl": "/static/img/oflogo.png",
            "tel": "",
            "time": updatetime,
            "user_id": user_id,
            "sequence": "",
            "comment_id": ""
        }, block_id]
        DataWebSocket.send_to_all(json_encode(msg))
class PageUpdateDomContentAPIHandler(WebRequest):
    # @tornado.gen.coroutine
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        block_id = self.get_argument("block_id",None)
        dom_owner = self.get_argument("dom_owner",None)
        dom_current = self.get_argument("dom_current",None)
        dom_content = self.get_argument("dom_content",None)
        
        updatetime = int(time.time())
        
        block = get_aim(block_id)
        #判断是否为编辑者
        if user_id not in block.get("editors",[block.get("owner",None)]):
            self.finish({"info":"error","about":"no in editors"})
            return
        dom_tree = dom_current.split("_")
        dom_aim = None
        doms = block.get("doms",[])

        _doms = doms
        for dom in dom_tree:
            _doms = _doms
            for _dom in _doms:
                if dom == _dom[0]:
                    if dom_owner == _dom[0]:
                        dom_aim = _dom
                        dom_aim[3] = json_decode(dom_content).get("text","")
                        dom_aim[6] =updatetime
                        break
                    _doms = _dom[5]
                    break
        block["doms"]=doms
        block["updatetime"]=updatetime

        update_aim(block_id,block)
        self.finish({"info":"ok"})
        content_data = {
            "dom_current":dom_current,
            "dom_content":dom_content,
        }
        msgtype = "COMMENTPAGEUPDATEDOMCONTENT"
        msg = [msgtype, {
            "content": content_data,
            "nickname": "",
            "headimgurl": "/static/img/oflogo.png",
            "tel": "",
            "time": updatetime,
            "user_id": user_id,
            "sequence": "",
            "comment_id": ""
        }, block_id]
        DataWebSocket.send_to_all(json_encode(msg))
class PageUpdateDomIframeAPIHandler(WebRequest):
    def post(self):
        if not self.current_user:
            self.finish({"info":"error","about":"no login"})
            return
        user_id = self.current_user["id"]
        block_id = self.get_argument("block_id",None)
        dom_owner = self.get_argument("dom_owner",None)
        dom_current = self.get_argument("dom_current",None)
        dom_content = self.get_argument("dom_content",None)
        
        updatetime = int(time.time())
        
        block = get_aim(block_id)
        #判断是否为编辑者
        if user_id not in block.get("editors",[block.get("owner",None)]):
            self.finish({"info":"error","about":"no in editors"})
            return
        dom_tree = dom_current.split("_")
        dom_aim = None
        doms = block.get("doms",[])

        _doms = doms
        for dom in dom_tree:
            _doms = _doms
            for _dom in _doms:
                if dom == _dom[0]:
                    if dom_owner == _dom[0]:
                        dom_aim = _dom
                        dom_aim[3] = json_decode(dom_content).get("text",{})
                        dom_aim[6] =updatetime
                        break
                    _doms = _dom[5]
                    break
        block["doms"]=doms
        block["updatetime"]=updatetime

        update_aim(block_id,block)
        self.finish({"info":"ok"})
        content_data = {
            "dom_current":dom_current,
            "dom_content":dom_content,
        }
        msgtype = "COMMENTPAGEUPDATEDOMIFRAME"
        msg = [msgtype, {
            "content": content_data,
            "nickname": "",
            "headimgurl": "/static/img/oflogo.png",
            "tel": "",
            "time": updatetime,
            "user_id": user_id,
            "sequence": "",
            "comment_id": ""
        }, block_id]
        DataWebSocket.send_to_all(json_encode(msg))
