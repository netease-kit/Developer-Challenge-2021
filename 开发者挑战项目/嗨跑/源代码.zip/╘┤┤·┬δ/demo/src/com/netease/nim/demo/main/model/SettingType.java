package com.netease.nim.demo.main.model;

/**
 * Created by hzxuwen on 2015/6/30.
 */
public interface SettingType {
    int TYPE_DEFAULE = 1;
    int TYPE_TOGGLE = 2;
    int TYPE_HEAD = 3;
    int TYPE_SEPERATOR = 4;
    int TYPE_LINE = 5;
}
