package com.netease.nim.demo.contact.constant;

/**
 * Created by hzxuwen on 2015/9/17.
 */
public class UserConstant {
    public static final int KEY_NICKNAME= 1;
    public static final int KEY_GENDER= 2;
    public static final int KEY_BIRTH= 3;
    public static final int KEY_PHONE= 4;
    public static final int KEY_EMAIL= 5;
    public static final int KEY_SIGNATURE = 6;
    public static final int KEY_ALIAS = 7;
}
