package com.netease.nim.demo.main.reminder;

public class ReminderId {
	final static public int INVALID = -1;
	final static public int SESSION = 0;
	final static public int CONTACT = 1;
}
