package com.netease.nim.demo.config;

/**
 * Created by jezhee on 4/19/15.
 */
public class ExtraOptions {

    public static void provide() {
        /// EMPTY NOW
   }
}
