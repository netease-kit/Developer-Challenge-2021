package com.netease.nim.demo.avchat.widgets;

/**
* Created by hzlichengda on 14-3-31.
*/
public enum ToggleState {
    DISABLE, //禁用
    OFF, // normal
    ON;  //selected
}
